



<?php

$variable1= 6;
$variable2= 5;

echo "Division:".round($variable1/$variable2)."<br>";
echo "Suma: ".round($variable1+$variable2)."<br>";
echo "Resta: ".round($variable1-$variable2)."<br>";
echo "Multiplicación: ".round($variable1*$variable2)."<br>";
?>





























