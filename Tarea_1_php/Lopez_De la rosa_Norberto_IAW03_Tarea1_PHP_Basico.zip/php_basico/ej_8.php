<html>
<head>
    <title></title>
</head>

<body>
    
<?php



$var=rand(1,5);

switch ($var) {
    case 1:
        echo "uno<br>";
        break;
    case 2:
        echo "dos<br>";
        break;
    case 3:
        echo "tres<br>";
        break;
    case 4:
        echo "cuatro<br>";
        break;
    case 5:
        echo "cinco<br>";
        break;
}

?>

</body>
</html>
