



<?php

$nombre="NORBERTO";

echo "<b>HOLA $nombre ENCANTADO DE CONOCERTE</b>"



?>





























