<html>
<head>
    <title></title>
</head>

<body>
    
<?php

$var='arriba';

switch ($var) {
    case 'arriba':
        echo "<b>arriba</b><br>";
        break;
    case 'abajo':
        echo "<b>abajo</b><br>";
        break;
    case 'derecha':
        echo "<b>derecha</b><br>";
        break;
    case 'izquierda':
        echo "<b>izquierda</b><br>";
        break;
}

?>

</body>
</html>
