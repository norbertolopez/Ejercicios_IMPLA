



<?php

$variable1= 4;
$variable2= 5;

if ($variable1>$variable2) {
    echo "$variable1 es mayor que $variable2";
}
elseif ($variable2>$variable1) {
    echo "$variable2 es mayor que $variable1";
}


?>






























