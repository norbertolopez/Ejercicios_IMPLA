<html>
<head>
    <title></title>
</head>

<body>
    
<?php



echo rand(0,100);

?>

</body>
</html>
